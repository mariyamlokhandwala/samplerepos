package com.nagarro.account.model;

import java.time.LocalDate;

public class Statement {
	private long Id;
	private long accountID;
	private LocalDate date;
	private long amount;
	
	public Statement(long id, long accountID, LocalDate date, long amount) {
		super();
		Id = id;
		this.accountID = accountID;
		this.date = date;
		this.amount = amount;
	}
	public Statement() {
	}
	public long getId() {
		return Id;
	}
	public void setId(long id) {
		Id = id;
	}
	public long getAccountID() {
		return accountID;
	}
	public void setAccountID(long accountID) {
		this.accountID = accountID;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	
	
	
}
