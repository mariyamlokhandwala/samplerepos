package com.nagarro.account.model;

public class Account {
	private long Id;
	private String accountType;
	private String accountNumber;
	
	public Account(long id, String accountType, String accountNumber) {
		super();
		Id = id;
		this.accountType = accountType;
		this.accountNumber = accountNumber;
	}
	public Account() {
	}
	public long getId() {
		return Id;
	}
	public void setId(long id) {
		Id = id;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	
}
