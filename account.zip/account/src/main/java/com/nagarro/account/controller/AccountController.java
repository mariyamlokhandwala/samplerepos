package com.nagarro.account.controller;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.nagarro.account.model.Statement;
import com.nagarro.account.service.AccountService;

@RestController
@RequestMapping("/rest/auth")
public class AccountController {
	@Autowired
	public AccountService accountService;
	private static final Logger LOGGER = LoggerFactory.getLogger(AccountController.class);
	
	@GetMapping(value="/statementByAmount",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Statement>> viewStatementByAmount(@RequestParam Long accountID,@RequestParam Long minAmount, @RequestParam Long maxAmount)  {
		LOGGER.debug("Triggered AccountController.viewStatementByAmount");
		
		if(accountService.accountExists(accountID)) {
		List<Statement> stmt=accountService.getStatementByAmount(accountID, minAmount,maxAmount);
		 return new ResponseEntity<>(stmt, HttpStatus.OK);
		 }
		else return ResponseEntity.notFound().build();
	}
	@GetMapping(value="/statementByDate",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Statement>> viewStatementByDate(@RequestParam Long accountID,@RequestParam String start, @RequestParam String end)  {
		LOGGER.debug("Triggered AccountController.viewStatementByDate");
	
		if(accountService.accountExists(accountID)) {
		List<Statement> stmt=accountService.getStatementByDate(accountID, start,end);
		return new ResponseEntity<>(stmt, HttpStatus.OK);
		}
		else return ResponseEntity.notFound().build();
	}
}
