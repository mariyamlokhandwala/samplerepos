package com.nagarro.account.service.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.nagarro.account.model.Account;
import com.nagarro.account.model.Statement;
import com.nagarro.account.service.AccountService;

@Service
public class AccountServiceImpl implements AccountService{
	@Autowired
	private JdbcTemplate jdbcTemplate;
	private static final Logger LOGGER = LoggerFactory.getLogger(AccountServiceImpl.class);
	
	public List<Account> getAllAccounts(){
		LOGGER.debug("Triggered AccountServiceImpl.getAllAccounts");	
		return jdbcTemplate.query("SELECT ID,account_type,account_number FROM account", new RowMapper<Account>() {
			@Override
			public Account mapRow(ResultSet rs, int rowNum) throws SQLException {
				return new Account(rs.getLong("ID"),rs.getString("account_type"),rs.getString("account_number"));
			}		
		});
	}
	
	public List<Statement> getAllStatements(){
		LOGGER.debug("Triggered AccountServiceImpl.getAllStatements");		
		return jdbcTemplate.query("SELECT ID,account_id,datefield,amount FROM statement", new RowMapper<Statement>() {
			@Override
			public Statement mapRow(ResultSet rs, int rowNum) throws SQLException {
			
				DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd.MM.yyyy");
				return new Statement(rs.getLong("ID"),rs.getLong("account_id"),LocalDate.parse(rs.getString("datefield"),formatter1),rs.getLong("amount"));
			}		
		});
	}

	@Override
	public List<Statement> getStatementByDate(long accountID, String start, String end) {
		LOGGER.debug("Triggered AccountServiceImpl.getStatementByDate");
		List<Statement>	accountStmt= getAllStatements();
		return accountStmt.stream().filter(a->a.getAccountID()==accountID && a.getDate().isAfter(LocalDate.parse(start)) && a.getDate().isBefore(LocalDate.parse(end))).collect(Collectors.toList());		
	}

	@Override
	public List<Statement> getStatementByAmount(long accountID, long minamount, long maxamount) {
		   LOGGER.debug("Triggered AccountServiceImpl.getStatementByAmount");
		   List<Statement>	accountStmt= getAllStatements();
		   return accountStmt.stream().filter(a->a.getAccountID()==accountID && a.getAmount()<maxamount && a.getAmount()>minamount).collect(Collectors.toList());	 
	}

	@Override
	public boolean accountExists(long accountID) {		
		 LOGGER.debug("Triggered AccountServiceImpl.getAccount");
		 List<Account> account=getAllAccounts();		
		 Optional<Account> matchingAccount=account.stream().filter(a-> a.getId()==accountID).findFirst();
		 return matchingAccount.isPresent();		 
	}

	@Override
	public List<Statement> getDefaultStatement(long accountID) {
		LOGGER.debug("Triggered AccountServiceImpl.getDefaultStatement");
		List<Statement>	accountStmt= getAllStatements();
		return accountStmt.stream().filter(a->a.getAccountID()==accountID && a.getDate().isAfter(LocalDate.now().minusMonths(3)) && a.getDate().isBefore(LocalDate.now())).collect(Collectors.toList());
	}
}
