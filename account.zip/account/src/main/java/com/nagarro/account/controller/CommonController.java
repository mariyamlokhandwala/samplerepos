package com.nagarro.account.controller;

import java.util.List;

import javax.security.auth.login.AccountException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.nagarro.account.model.Statement;
import com.nagarro.account.service.AccountService;

@RestController
@RequestMapping("/rest/noauth")
public class CommonController {
	@Autowired
	public AccountService accountService;
	private static final Logger LOGGER = LoggerFactory.getLogger(CommonController.class);
	
	@GetMapping(value = "/default", produces = MediaType.APPLICATION_JSON_VALUE)	
	public ResponseEntity<List<Statement>> viewDefaultStatement(@RequestParam Long accountID) throws AccountException {
		LOGGER.debug("Triggered CommonController.viewDefaultStatement");
		
		if(accountService.accountExists(accountID)) {
		List<Statement> stmt=accountService.getDefaultStatement(accountID);
		 return new ResponseEntity<>(stmt, HttpStatus.OK);
		 }
		else return ResponseEntity.notFound().build();
	}
}
