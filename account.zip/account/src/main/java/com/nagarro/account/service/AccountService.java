package com.nagarro.account.service;
import java.util.List;

import com.nagarro.account.model.Account;
import com.nagarro.account.model.Statement;

public interface AccountService {
	public List<Account> getAllAccounts();
	public boolean accountExists(long accountID);
	public List<Statement> getAllStatements();
	public List<Statement> getStatementByDate(long accountID, String start, String end); 
	public List<Statement> getStatementByAmount(long accountID, long minamount, long maxamount);
	public List<Statement> getDefaultStatement(long accountID);
}
