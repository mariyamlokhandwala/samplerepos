package com.nagarro.account;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import java.time.LocalDate;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.web.WebAppConfiguration;
import com.nagarro.account.model.Account;
import com.nagarro.account.model.Statement;
import com.nagarro.account.service.impl.AccountServiceImpl;
@SpringBootTest
@WebAppConfiguration
class AccountServiceImplTests {
	 
	@Mock
	AccountServiceImpl accountService;
	
	@Test
	 void testgetAllAccounts() {
		Account acc1 =new Account();
		acc1.setId(1);	acc1.setAccountNumber("2002333"); acc1.setAccountType("savings");	
		when(accountService.getAllAccounts()).thenReturn(Stream.of(acc1,new Account(2,"current","500233")).collect(Collectors.toList()));
		assertEquals(2, accountService.getAllAccounts().size());
		assertEquals(1, accountService.getAllAccounts().get(0).getId());
		assertEquals("savings", accountService.getAllAccounts().get(0).getAccountType());
		assertEquals("2002333", accountService.getAllAccounts().get(0).getAccountNumber());
	}
	@Test
	 void testgetDefaultStatement() {
		Statement stmt= new Statement();
		stmt.setAccountID(1);stmt.setAmount(1313);stmt.setId(1);stmt.setDate(LocalDate.now());
		when(accountService.getDefaultStatement(1)).thenReturn(Stream.of(stmt,new Statement(2,1,LocalDate.now(),500233)).collect(Collectors.toList()));
		assertEquals(2, accountService.getDefaultStatement(1).size());
		assertEquals(1, accountService.getDefaultStatement(1).get(0).getAccountID());
		assertEquals(1313, accountService.getDefaultStatement(1).get(0).getAmount());
		assertEquals(1, accountService.getDefaultStatement(1).get(0).getId());
		assertEquals(LocalDate.now(), accountService.getDefaultStatement(1).get(0).getDate());
	}
	@Test
	void testgetAllStatements() {
		when(accountService.getAllStatements()).thenReturn(Stream.of(new Statement(1,1,LocalDate.now(),1313),new Statement(2,2,LocalDate.now(),500233)).collect(Collectors.toList()));
		assertEquals(2, accountService.getAllStatements().size());
	}
	@Test
	void testgetStatementByAmount() {
		when(accountService.getStatementByAmount(1, 50, 100)).thenReturn(Stream.of(new Statement(1,1,LocalDate.now(),1313)).collect(Collectors.toList()));
		assertEquals(1, accountService.getStatementByAmount(1,50,100).size());
	}
	@Test
	void getStatementByDate() {
		when(accountService.getStatementByDate(2, LocalDate.now().minusMonths(3).toString(),  LocalDate.now().toString())).thenReturn(Stream.of(new Statement(2,2,LocalDate.now(),500233)).collect(Collectors.toList()));
		assertEquals(1, accountService.getStatementByDate(2,LocalDate.now().minusMonths(3).toString(),  LocalDate.now().toString()).size());
	}
	@Test
	void getAccount() {
		when(accountService.accountExists(1)).thenReturn(true);
		assertEquals(true, accountService.accountExists(1));
	}
	@Test
	void getAccountNotExists() {
		when(accountService.accountExists(6)).thenReturn(false);
		assertEquals(false, accountService.accountExists(6));
	}
	
}
